<?php

if('POST' == $_SERVER['REQUEST_METHOD'])
{
    //echo ('h');
    include __DIR__.'/t.php';
    
    //translate(src,dest,text)
    //detect(text)

    try {

        //var_dump($_POST);
        $inputStr = "crise";
        //Set the params.//
        $langs = ["en","es","fr","ru","de"];
        //var_dump($langs);
        $queryLanguage = "en";
        $toLanguage   = "es";
        $inputStr     = urldecode ($_POST["q"]);
        //echo $inputStr;
        $contentType  = 'text/plain';
        $category     = 'general';
        
        $queryLanguage = detect($inputStr);
        //echo $queryLanguage;
        $boosts = "+";
        foreach ($langs as $l) {
            //echo ($l);
            $score = 1;
            if($queryLanguage == $l){
                $score = 2.3;
            }
            $boosts .= "text_".$l."^".$score."+";
        }
        $boosts = rtrim($boosts,"+");
        
        $q = "";
        foreach ($langs as $l){
            if($queryLanguage == $l){
                $q .= "text_".$l."=".urlencode($inputStr).",";
            }else{
                $q .= "text_".$l."=".urlencode(translate($queryLanguage,$l,$inputStr)).",";
            }
        }
        $q = rtrim($q,',');
        
        
        $query = "http://susmitha.koding.io:8983/solr/"
                 ."twitter3"
                 ."/select?"
                 ."fl=id%2Cscore%2Cuser_name%2Ctext%2Ccreated_at%2Cfavorite_count%2Cretweet_count%2Cuser_verified%2Clang"
                 ."&wt=json&rows=100&indent=true&defType=dismax&"
                 ."qf=tweet_hashtags^1.5+user_verified^1.25"
                 .$boosts
                 ."&mm=1&"
                 ."q="
                 .$q
                 ;
                 
        
        
        
        //echo($query);
        $c = curl_init();
        curl_setopt($c,CURLOPT_URL,$query); 
        
        $res = curl_exec($c);
        $status = curl_getinfo($c,CURLINFO_HTTP_CODE);
        $err = curl_error($c);
        //Interprets a string of XML into an object.
        echo($res[0]);
        //echo '\n';
        //var_dump($status);
        //var_dump($err);
        
        curl_close($c);

    } catch (Exception $e) {
        echo "Exception: " . $e->getMessage() . PHP_EOL;
    }
}

?>