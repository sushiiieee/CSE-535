<?php
header('Content-Type: text/html; charset=utf-8');

require_once(__DIR__.'/translate.class.php');
//$BingTranslator = new BingTranslator('narmadha1993', '+zqSBSPZ1QwJxwkg265KBopm9DhMsOjoEAJ3WO7CrQk=');
 

//echo 'hi';

function translate($src,$dest,$txt){
//{
$BingTranslator = new BingTranslator('narmadha1993', '+zqSBSPZ1QwJxwkg265KBopm9DhMsOjoEAJ3WO7CrQk=');
$translation = $BingTranslator->getTranslation($src,$dest,$txt);
 
//string utf8_encode ( string $data )
//echo iconv('utf-8', 'utf-16le', $translation);
return ($translation);
}
//$trans=translate("en","de","How are you?");
//echo $trans;
//}
function detect($txt)
{
$BingTranslator = new BingTranslator('narmadha1993', '+zqSBSPZ1QwJxwkg265KBopm9DhMsOjoEAJ3WO7CrQk=');
$detection = $BingTranslator->getDetection($txt);
return ($detection);
}
?>