<html>
<body>
<?php
echo 'hi';
echo phpinfo();
?>
</body>
</html>

